# Read Me for Example Folder
In diesem Ordner liegt ein Beispiel auf Basis des Templates.
