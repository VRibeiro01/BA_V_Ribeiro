# Read Me for Style Folder
In diesem Ordner liegt das Style-File, das die Standardpakete und Einstellungen enthält. An diesen Dateien sollten keine Änderungen vom Nutzer des Templates erforderlich sein. Die Steuerung erfolgt durch lokale Konfigurationsdateien.
